﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

static class AesExample
{
    class AesEcb
    {
        public AesEcb(byte[] key)
        {
            CheckSize(key);
            aesAlg = Aes.Create();
            aesAlg.KeySize = KeyDataLength * 8;
            aesAlg.Key = key;
            aesAlg.BlockSize = KeyDataLength * 8;
            aesAlg.Mode = CipherMode.ECB;
            aesAlg.Padding = PaddingMode.Zeros;
            aesAlg.IV = new byte[16];
        }

        public byte[] EncodeRaw(byte[] block)
        {
            CheckSize(block);
            ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
            return encryptor.TransformFinalBlock(block, 0, block.Length);
        }

        public byte[] DecodeRaw(byte[] block)
        {
            CheckSize(block);
            ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
            return decryptor.TransformFinalBlock(block, 0, block.Length);
        }

        // !!shuffle these, except for the zero!!
        private const string PrivChars = "\0" + "0123456789" + "ABCDEFGHIJKLMNOPQRSTUVWXYZ" +
            "abcdefghijklmnopqrstuvwxyz" + "АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ" + "абвгдежзийклмнопрстуфхцчшщъыьэюя";

        private const int MinPrivLength = 10;
        private const int MaxPrivLength = 16;
        private const int KeyDataLength = 16;

        private static readonly byte[] XorValue = { 0, 224, 136, 5, 145, 243, 79, 39, 107, 211, 253, 158, 80, 201, 188, 0 };

        private static void XorBlock(byte[] block)
        {
            for (int i = 0; i < block.Length; i++)
                block[i] ^= XorValue[i];
        }

        public static byte[] PackPriv(string input)
        {
            uint value;

            CheckPriv(input);
            input += '\0';

            try
            {
                int charNo = input[MinPrivLength] != '\0' ? MinPrivLength : 0;

                value = Convert.ToUInt32(input.Substring(1, MinPrivLength - 1));
                value = value | (byte) (PrivChars.IndexOf(input[charNo]) << 25);
            }
            catch
            {
                value = 0;

                for (int charNo = 1; charNo < MinPrivLength; charNo += 2)
                    value = (value << 7) | (byte) PrivChars.IndexOf(input[charNo]);
            }

            my_srand((uint) value);

            byte[] block = new byte[KeyDataLength];
            short random = my_rand();
            int dstByteNo = 0;
            int dstBitNo = 0;

            block[0] = (byte) (random & 0xFF);

            for (int srcCharNo = 0; srcCharNo < MaxPrivLength; srcCharNo++)
            {
                byte srcByte = (byte) PrivChars.IndexOf(input[srcCharNo]);
                
                for (int srcBitNo = 6; srcBitNo >= 0; srcBitNo--)
                {
                    if (--dstBitNo < 0)
                    {
                        dstBitNo = 7;
                        dstByteNo++;
                    }

                    if ((srcByte & (1 << srcBitNo)) != 0)
                        block[dstByteNo] |= (byte) (1 << dstBitNo);
                }

                if (srcByte == 0)
                    break;
            }

            while (++dstByteNo < KeyDataLength - 1)
                block[dstByteNo] = (byte) (my_rand() & 0xFF);

            block[KeyDataLength - 1] = (byte) (random >> 8);
            XorBlock(block);
            return block;
        }

        public static string UnpackPriv(byte[] block)
        {
            StringBuilder input = new StringBuilder(MaxPrivLength);
            int dstByteNo = 0;
            int dstBitNo = 0;

            XorBlock(block);

            for (int srcCharNo = 0; srcCharNo < MaxPrivLength; srcCharNo++)
            {
                byte srcByte = 0;

                for (int srcBitNo = 6; srcBitNo >= 0; srcBitNo--)
                {
                    if (--dstBitNo < 0)
                    {
                        dstBitNo = 7;
                        dstByteNo++;
                    }

                    if ((block[dstByteNo] & (1 << dstBitNo)) != 0)
                        srcByte |= (byte) (1 << srcBitNo);
                }

                if (srcByte == 0)
                    break;

                input.Append(PrivChars[srcByte]);
            }

            return input.ToString();
        }

        public byte[] EncodePriv(string input)
        {
            return EncodeRaw(PackPriv(input));
        }

        public string DecodePriv(byte[] block)
        {
            return UnpackPriv(DecodeRaw(block));
        }

        public string PrivToBase64(string input)
        {
            string base64 = Convert.ToBase64String(EncodePriv(input));
            return base64.Replace('+', '.').Replace('/', '-');
        }

        public string PrivFromBase64(string base64)
        {
            base64 = base64.Replace('-', '/').Replace('.', '+');
            return DecodePriv(Convert.FromBase64String(base64));
        }

        private static void CheckPriv(string input)
        {
            if (input.Length < MinPrivLength || input.Length > MaxPrivLength)
                throw new ArgumentException("Invalid private data length");

            foreach (char srcChar in input)
                if (PrivChars.IndexOf(srcChar) == -1)
                    throw new ArgumentException("Invalid private data content");
        }

        private static void CheckSize(byte[] data)
        {
            if (data.Length != KeyDataLength)
                throw new InvalidDataException("Invalid coder block length");
        }

        private Aes aesAlg;

        /// obsolete ///
        private const int MinUcnLength = 9;
        private const int MaxUcnLength = 15;

        public static byte[] PackUcn(char ucnType, string ucn)
        {
            uint value;

            try
            {
                int charNo = ucn[MinUcnLength] != '\0' ? MinUcnLength : 0;

                value = Convert.ToUInt32(ucn.Substring(0, MinUcnLength));
                value = value | (byte) (PrivChars.IndexOf(ucn[MinUcnLength]) << 25);
            }
            catch
            {
                value = 0;

                for (int charNo = 0; charNo < MinUcnLength; charNo += 2)
                    value = (value << 7) | (byte) PrivChars.IndexOf(ucn[charNo]);
            }

            CheckUcn(ucnType, ucn);
            my_srand((uint) value);

            byte[] block = new byte[KeyDataLength];
            short random = my_rand();
            string srcText = ucnType + ucn + '\0';
            int dstByteNo = 0;
            int dstBitNo = 0;

            block[0] = (byte) (random & 0xFF);

            for (int srcCharNo = 0; srcCharNo < MaxUcnLength; srcCharNo++)
            {
                byte srcByte = (byte) PrivChars.IndexOf(srcText[srcCharNo]);
                
                for (int srcBitNo = 6; srcBitNo >= 0; srcBitNo--)
                {
                    if (--dstBitNo < 0)
                    {
                        dstBitNo = 7;
                        dstByteNo++;
                    }

                    if ((srcByte & (1 << srcBitNo)) != 0)
                        block[dstByteNo] |= (byte) (1 << dstBitNo);
                }

                if (srcByte == 0)
                    break;
            }

            while (++dstByteNo < KeyDataLength - 1)
                block[dstByteNo] = (byte) (my_rand() & 0xFF);

            block[KeyDataLength - 1] = (byte) (random >> 8);
            XorBlock(block);
            return block;
        }

        public static string UnpackUcn(byte[] block, out char ucnType)
        {
            string srcText = "";
            int dstByteNo = 0;
            int dstBitNo = 0;

            XorBlock(block);

            for (int srcCharNo = 0; srcCharNo < MaxUcnLength; srcCharNo++)
            {
                byte srcByte = 0;

                for (int srcBitNo = 6; srcBitNo >= 0; srcBitNo--)
                {
                    if (--dstBitNo < 0)
                    {
                        dstBitNo = 7;
                        dstByteNo++;
                    }

                    if ((block[dstByteNo] & (1 << dstBitNo)) != 0)
                        srcByte |= (byte) (1 << srcBitNo);
                }

                if (srcByte == 0)
                    break;

                srcText += PrivChars[srcByte];
            }

            ucnType = srcText[0];
            string ucn = srcText.Substring(1);

            CheckUcn(ucnType, ucn);
            return ucn;
        }

        public byte[] EncodeUcn(char ucnType, string ucn)
        {
            return EncodeRaw(PackUcn(ucnType, ucn));
        }

        public string DecodeUcn(byte[] block, out char ucnType)
        {
            return UnpackUcn(DecodeRaw(block), out ucnType);
        }

        private static void CheckUcn(char ucnType, string ucn)
        {
            if (!Char.IsLetter(ucnType) || Convert.ToByte(ucnType) >= 127)
                throw new InvalidDataException("Invalid coder data type");

            if (ucn.Length < MinUcnLength || ucn.Length > MaxUcnLength)
                throw new InvalidDataException("Invalid coder data length");
        }
    }

    private static void PrintBytes(byte[] bytes)
    {
        string[] formats = new string[2] { "X2", "D" };
        string[] systems = new string[2] { "hex", "dec" };

        for (int sys = 0; sys < 2; sys++)
        {
            Console.Write(systems[sys] + ": ");

            for (int i = 0; i < bytes.Length; i++)
                Console.Write(bytes[i].ToString(formats[sys]) + ' ');

            Console.Write('\n');
        }
    }

    public static void Main()
    {
        byte[] Key = { 105, 100, 16, 39, 215, 248, 192, 68, 106, 152, 238, 166, 127, 92, 36, 3 };
        byte[] encoded = { 255, 196, 228, 119, 227, 157, 21, 133, 81, 210, 37, 136, 221, 52, 211, 255 };
        byte[] decoded = { 98, 62, 137, 80, 144, 77, 50, 96, 200, 35, 207, 172, 50, 157, 97, 65 };
        AesEcb myAes = new AesEcb(Key);
        int variant = 4;

        switch (variant)
        {
            case 1 :
            {
                byte[] result = myAes.DecodeRaw(encoded);
                PrintBytes(result);
                break;
            }
            case 2 :
            {
                byte[] result = myAes.EncodeRaw(decoded);
                PrintBytes(result);
                break;
            }
            case 3 :
            {
                byte[] resultPriv = AesEcb.PackPriv("c7106051022");
                string input = AesEcb.UnpackPriv(resultPriv);
                byte[] resultUcn = AesEcb.PackUcn('c', "7106051022");
                char ucnType;
                string ucn = AesEcb.UnpackUcn(resultUcn, out ucnType);

                PrintBytes(resultPriv);
                Console.WriteLine(input);
                PrintBytes(resultUcn);
                Console.WriteLine("{0}{1}", ucnType, ucn);
                break;
            }
            case 4 :
            {
                byte[] resultPriv = myAes.EncodePriv("c7106051022");
                string input = myAes.DecodePriv(resultPriv);
                byte[] resultUcn = myAes.EncodeUcn('c', "7106051022");
                char ucnType;
                string ucn = myAes.DecodeUcn(resultUcn, out ucnType);

                PrintBytes(resultPriv);
                Console.WriteLine(input);
                PrintBytes(resultUcn);
                Console.WriteLine("{0}{1}", ucnType, ucn);
                break;
            }
            /*case 5 :
            {
                string resultPriv = myAes.PrivToBase64("c7106051022");
                string input = myAes.PrivFromBase64(resultPriv);
                byte[] resultUcn = myAes.UcnToBase64('c', "7106051022");
                char ucnType;
                string ucn = myAes.UcnFromBase64(resultUcn, out ucnType);

                Console.WriteLine(resultPriv);
                Console.WriteLine(input);
                Console.WriteLine(resultUcn);
                Console.WriteLine("{0}{1}", ucnType, ucn);
                break;
            }*/
        }

        Console.ReadKey();
    }

    const int RAND_MULTIPLIER = 0x015a4e35;
    const int RAND_INCREMENT = 1;
    static int RandSeed = 1;

    public static void my_srand(uint seed)
    {
        RandSeed = (int) seed;
    }

    public static short my_rand()
    {
        RandSeed = RAND_MULTIPLIER * RandSeed + RAND_INCREMENT;
        return (short) ((int) (RandSeed >> 16) & 0x7fff);
    }
}
